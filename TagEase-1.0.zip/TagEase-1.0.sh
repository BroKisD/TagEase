#!/bin/bash
echo "Starting TagEase..."
java -jar TagEase-1.0.jar
